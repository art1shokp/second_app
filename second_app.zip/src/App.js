import React from 'react';
// import logo from './logo.svg';
import './App.css';
import Test from './companet/Test';
function App() {
  return (
    <div className="App">
      <header className="App-header">
      </header>
      <Test/>
    </div>
  );
}

export default App;
